#ifndef METER_H
#define METER_H

extern double alertness;
extern double hygiene;
extern double timeRate;
extern double work;
extern double bladder;
extern double timeProgress;
extern void meterInit();

extern void meterGameFrame(void);

#endif